package com.innotek.cookieandsessiondemo02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cookieandsessiondemo02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
